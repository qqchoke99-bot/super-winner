#!/bin/bash
set -e

VERSION="0.1.0-beta-1.26.51"
OUT="SoundPhysicsLite-${VERSION}.levipack"

if [ ! -f "libSoundPhysicsLite.so" ]; then
    echo "Error: libSoundPhysicsLite.so not found!"
    echo "Please build the library first (see README.md)"
    exit 1
fi

rm -rf _package
mkdir -p _package

cp manifest.json _package/
cp libSoundPhysicsLite.so _package/
cp -r config _package/
[ -f icon.png ] && cp icon.png _package/

cd _package
zip -r "../${OUT}" .
cd ..
rm -rf _package

echo "Created: ${OUT}"
ls -lh "${OUT}"
